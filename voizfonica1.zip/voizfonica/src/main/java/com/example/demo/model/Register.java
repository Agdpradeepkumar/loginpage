package com.example.demo.model;

import lombok.Data;
import org.springframework.stereotype.Controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Controller

public class Register {

    @NotBlank
    @Size(min = 2,message = "Atleast 2 characters")
    private String full_name;

    @NotBlank
    @Size(min = 5,message = "Must be minimum 5 characters")
    private String password;




}
